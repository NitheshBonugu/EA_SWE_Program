#ifndef GAMECLASS_H
#define GAMECLASS_H

#include <fstream>
#include <string>
#include <ctime>
#include <random>
#include <vector>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <QTimer>
#include <QObject>
#include <QApplication>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include "pacman.h"
#include "ghost.h"
#include "blinky.h"
#include "pinky.h"
#include "clyde.h"
#include "inky.h"
#include <QTimerEvent>  // A new timer is needed for ghost doubling event. For reference, see https://doc.qt.io/qt-5/qtimerevent.html#QTimerEvent


class   GameLoop : public QGraphicsView
{
	
  Q_OBJECT
private:
    QGraphicsScene                          *scene = nullptr;
    QGraphicsView                           *view = nullptr;
    QGraphicsPixmapItem                     **map_pix = nullptr;
    PacMan                                  *pacman = nullptr;

    int                                     **map_int;
    QTimer                                  *timer_pacman = nullptr;
    bool gameIsLost = false;                                                   // Game stopping variable

    QTimer                                  *timer_double_ghosts = nullptr;    // Timer for the doubling gosts

    Blinky                                  *blinkys[128];  // Add some room for multiple ghosts (At most 128 when the game is over)
    Pinky                                   *pinkys[128];   // Add some room for multiple ghosts (At most 128 when the game is over)
    Inky                                    *inkys[128];    // Add some room for multiple ghosts (At most 128 when the game is over)
    Clyde                                   *clydes[128];   // Add some room for multiple ghosts (At most 128 when the game is over)

    QTimer                                  *timer_blinkys[128];
    QTimer                                  *timer_pinkys[128];
    QTimer                                  *timer_inkys[128];
    QTimer                                  *timer_clydes[128];

public:
                                            GameLoop(char *file_name);
                                            ~GameLoop();
    void                                    ft_write_line_map(int *map, std::string str);
    void                                    ft_roll_game();
    void                                    ft_create_map();
    int                                     ft_check_file_inp(std::string str);
// CHANGE	

    void ft_set_is_game_lost(bool isLost);
public slots:
    void                                    ghostDoubling();  // Function for doubling ghosts
    void                                    ghostDied();

};

#endif // GAMECLASS_H
